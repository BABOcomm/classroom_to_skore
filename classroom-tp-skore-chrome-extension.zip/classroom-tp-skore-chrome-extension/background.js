chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'FETCH_CLASSROOM_DATA') {
    fetchClassroomData()
      .then(data => sendResponse({ success: true, data }))
      .catch(error => {
        console.error('Fout bij ophalen Classroom data:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});



async function getAuthToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (!token) {
        reject(new Error('Geen authenticatie-token ontvangen van Google.'));
      } else {
        resolve(token);
      }
    });
  });
}

async function apiFetch(url, token) {
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) {
    const errorBody = await res.text().catch(() => '');
    throw new Error(`API Fout (${res.status}): ${res.statusText} ${errorBody ? '- ' + errorBody : ''}`);
  }
  return await res.json();
}

// HELPER OM ALLE RESULTATEN OP TE HALEN MET PAGINERING
async function apiFetchAll(baseUrl, key, token) {
  let items = [];
  let pageToken = '';
  do {
    const fetchUrl = new URL(baseUrl);
    fetchUrl.searchParams.set('pageSize', '100');
    if (pageToken) {
      fetchUrl.searchParams.set('pageToken', pageToken);
    }
    const res = await apiFetch(fetchUrl.toString(), token);
    if (res[key] && Array.isArray(res[key])) {
      items = items.concat(res[key]);
    }
    pageToken = res.nextPageToken || '';
  } while (pageToken);
  return items;
}

function getSchoolYearRange() {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  const startYear = currentMonth >= 8 ? currentYear : currentYear - 1;
  const startDate = new Date(startYear, 8, 1, 0, 0, 0);
  const endDate = new Date(startYear + 1, 7, 31, 23, 59, 59);

  return { startDate, endDate };
}

async function fetchClassroomData() {
  const token = await getAuthToken();

  // Halen alle actieve vakken op met paginering
  const courses = await apiFetchAll('https://classroom.googleapis.com/v1/courses?teacherId=me&courseStates=ACTIVE', 'courses', token);

  if (courses.length === 0) return [];

  const { startDate, endDate } = getSchoolYearRange();

  const assignmentsPromises = courses.map(async (course) => {
    // Halen alle leerlingen en opdrachten op per vak met paginering
    const [studentsList, courseworkList] = await Promise.all([
      apiFetchAll(`https://classroom.googleapis.com/v1/courses/${course.id}/students`, 'students', token).catch(() => []),
      apiFetchAll(`https://classroom.googleapis.com/v1/courses/${course.id}/courseWork?courseWorkStates=PUBLISHED`, 'courseWork', token).catch(() => [])
    ]);

    const studentMap = {};
    studentsList.forEach(s => {
      const name = s.profile.name;
      const fullName = name.familyName ? `${name.familyName} ${name.givenName || ''}`.trim() : name.fullName;
      studentMap[s.userId] = fullName;
    });

    const courseAssignments = await Promise.all(
      courseworkList.map(async (work) => {
        const creationDate = new Date(work.creationTime);

        let rawDueDate = null;
        let formattedDate = null;
        if (work.dueDate) {
          const yyyy = work.dueDate.year;
          const mm = String(work.dueDate.month).padStart(2, '0');
          const dd = String(work.dueDate.day).padStart(2, '0');
          formattedDate = `${yyyy}-${mm}-${dd}`;
          rawDueDate = new Date(work.dueDate.year, work.dueDate.month - 1, work.dueDate.day);
        }

        const isCreatedInSchoolYear = creationDate >= startDate && creationDate <= endDate;
        const isDueInSchoolYear = rawDueDate && (rawDueDate >= startDate && rawDueDate <= endDate);

        if (!isCreatedInSchoolYear && !isDueInSchoolYear) {
          return null;
        }

        let submissions = [];
        try {
          submissions = await apiFetchAll(`https://classroom.googleapis.com/v1/courses/${course.id}/courseWork/${work.id}/studentSubmissions`, 'studentSubmissions', token);
        } catch (e) {
          console.warn(`Kon inzendingen niet laden voor ${work.title}`, e);
        }

        let ingeleverdCount = 0;
        let toegewezenCount = 0;
        let beoordeeldCount = 0;
        const studentsData = [];

        submissions.forEach(sub => {
          const studentName = studentMap[sub.userId] || `Leerling (${sub.userId})`;
          const maxPoints = work.maxPoints || 20;

          // Google Classroom API statussen:
          // - RETURNED: Beoordeeld & teruggegeven aan leerling
          // - TURNED_IN / STUDENT_EDITED_AFTER_TURN_IN: Ingeleverd
          // - NEW / CREATED / RECLAIMED_BY_STUDENT: Toegewezen (nog niet ingeleverd)
          if (sub.state === 'RETURNED') {
            beoordeeldCount++;
          } else if (sub.state === 'TURNED_IN' || sub.state === 'STUDENT_EDITED_AFTER_TURN_IN') {
            ingeleverdCount++;
          } else {
            toegewezenCount++;
          }

          let gradeStr = 'Nog geen punt';
          let isDraft = false;

          if (sub.assignedGrade !== undefined) {
            gradeStr = `${sub.assignedGrade}/${maxPoints}`;
            isDraft = false;
          } else if (sub.draftGrade !== undefined) {
            gradeStr = `${sub.draftGrade}/${maxPoints}`;
            isDraft = true;
          }

          studentsData.push({
            name: studentName,
            grade: gradeStr,
            isDraft: isDraft
          });
        });

        // Als er ingeschreven leerlingen zijn waarvoor de API nog geen submissie-object aanmaakte:
        const totalEnrolled = Object.keys(studentMap).length;
        if (totalEnrolled > submissions.length) {
          toegewezenCount += (totalEnrolled - submissions.length);
        }

        studentsData.sort((a, b) => a.name.localeCompare(b.name));

        return {
          id: work.id,
          title: work.title,
          course: course.name,
          dueDateStr: formattedDate,
          dueDateTimestamp: rawDueDate ? rawDueDate.getTime() : 0,
          creationTimestamp: creationDate.getTime(),
          ingeleverd: ingeleverdCount,
          toegewezen: toegewezenCount,
          beoordeeld: beoordeeldCount,
          students: studentsData
        };
      })
    );

    return courseAssignments.filter(Boolean);
  });

  const resultsNested = await Promise.all(assignmentsPromises);
  return resultsNested.flat();
}
