(function () {
  if (document.getElementById('ba-skore-popup')) return;

  let classroomAssignments = [];
  let currentSelectedAssignment = null;
  let overviewScrollTop = 0;
  let selectedCourseFilter = 'ALL'; // Standaard: alle klassen tonen

  // SORTEERSTATUS (Standaard: datum recentste boven)
  let sortState = {
    mode: 'date',
    dir: 'desc'
  };

  // SVGs
  const logoSvg = `
    <svg viewBox="0 0 1211 280" version="1.1" xmlns="http://www.w3.org/2000/svg" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;">
      <circle style="fill:#000000;stroke-width:4.53543;stroke-linecap:round;stroke-linejoin:round" cx="138.789" cy="138.789" r="126.655" />
      <g transform="matrix(1,0,0,1,-3797.51,-2584.81)">
        <g transform="matrix(1,0,0,1,39.6302,1970.64)">
          <path id="BOL" fill="#86BC25" fill-rule="evenodd" d="M3897.4,614.177C3974.4,614.177 4036.92,676.693 4036.92,753.695C4036.92,830.696 3974.4,893.212 3897.4,893.212C3820.4,893.212 3757.89,830.696 3757.89,753.695C3757.89,676.693 3820.4,614.177 3897.4,614.177ZM3867.62,818.95C3865.5,819.162 3863.3,819.268 3861.02,819.268L3808.64,819.268L3808.64,688.31L3858.58,688.31C3867.49,688.31 3875.16,689.817 3881.56,692.832C3887.97,695.847 3892.81,699.898 3896.07,704.986C3899.34,710.073 3900.97,715.757 3900.97,722.038C3900.97,729.576 3898.96,735.857 3894.94,740.881C3890.92,745.906 3885.52,749.612 3878.74,751.999C3885.77,753.255 3891.74,756.961 3896.64,763.116C3896.8,763.325 3896.97,763.535 3897.13,763.747L3937.55,688.121L3962.42,688.121L3986.16,819.268L3963.55,819.268L3958.84,792.511L3904.01,792.511L3889.88,819.268L3867.45,819.268L3867.62,818.95ZM3859.14,801.744C3866.43,801.744 3872.14,799.985 3876.29,796.468C3880.43,792.951 3882.51,788.051 3882.51,781.77C3882.51,775.364 3880.31,770.276 3875.91,766.508C3871.51,762.739 3865.67,760.855 3858.39,760.855L3830.12,760.855L3830.12,801.744L3859.14,801.744ZM3956.01,775.741L3945.27,714.124L3912.87,775.741L3956.01,775.741ZM3830.12,743.331L3856.69,743.331C3863.72,743.331 3869.22,741.729 3873.18,738.526C3877.14,735.323 3879.11,730.706 3879.11,724.676C3879.11,718.772 3877.14,714.156 3873.18,710.827C3869.22,707.498 3863.72,705.834 3856.69,705.834L3830.12,705.834L3830.12,743.331Z"/>
          <g transform="matrix(3.01486,0,0,3.01486,3287.26,-677.523)" fill="#000000">
            <g transform="matrix(62.5,0,0,62.5,274.038,496.471)"><path d="M0.447,-0.357C0.484,-0.35 0.516,-0.331 0.542,-0.298C0.568,-0.265 0.581,-0.228 0.581,-0.187C0.581,-0.152 0.572,-0.12 0.554,-0.092C0.535,-0.063 0.509,-0.041 0.474,-0.025C0.439,-0.008 0.399,-0 0.353,-0L0.075,-0L0.075,-0.695L0.34,-0.695C0.387,-0.695 0.428,-0.687 0.462,-0.671C0.496,-0.655 0.522,-0.634 0.539,-0.607C0.556,-0.58 0.565,-0.549 0.565,-0.516C0.565,-0.476 0.554,-0.443 0.533,-0.416C0.512,-0.389 0.483,-0.37 0.447,-0.357ZM0.189,-0.403L0.33,-0.403C0.367,-0.403 0.397,-0.412 0.418,-0.429C0.439,-0.446 0.449,-0.47 0.449,-0.502C0.449,-0.533 0.439,-0.558 0.418,-0.576C0.397,-0.593 0.367,-0.602 0.33,-0.602L0.189,-0.602L0.189,-0.403ZM0.343,-0.093C0.382,-0.093 0.412,-0.102 0.434,-0.121C0.456,-0.14 0.467,-0.166 0.467,-0.199C0.467,-0.233 0.455,-0.26 0.432,-0.28C0.409,-0.3 0.378,-0.31 0.339,-0.31L0.189,-0.31L0.189,-0.093L0.343,-0.093Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,314.663,496.471)"><path d="M0.314,0.009C0.262,0.009 0.215,-0.003 0.173,-0.027C0.131,-0.05 0.098,-0.084 0.074,-0.127C0.05,-0.169 0.038,-0.219 0.038,-0.276C0.038,-0.332 0.05,-0.382 0.075,-0.425C0.1,-0.468 0.133,-0.502 0.176,-0.525C0.219,-0.548 0.266,-0.56 0.319,-0.56C0.372,-0.56 0.419,-0.548 0.462,-0.525C0.505,-0.502 0.538,-0.468 0.563,-0.425C0.588,-0.382 0.6,-0.332 0.6,-0.276C0.6,-0.22 0.587,-0.17 0.562,-0.127C0.537,-0.084 0.502,-0.05 0.459,-0.027C0.415,-0.003 0.367,0.009 0.314,0.009ZM0.314,-0.09C0.343,-0.09 0.371,-0.097 0.397,-0.111C0.422,-0.125 0.443,-0.146 0.459,-0.174C0.475,-0.202 0.483,-0.236 0.483,-0.276C0.483,-0.316 0.475,-0.35 0.46,-0.378C0.445,-0.405 0.424,-0.426 0.399,-0.44C0.374,-0.454 0.346,-0.461 0.317,-0.461C0.288,-0.461 0.261,-0.454 0.236,-0.44C0.211,-0.426 0.191,-0.405 0.176,-0.378C0.161,-0.35 0.154,-0.316 0.154,-0.276C0.154,-0.217 0.169,-0.171 0.2,-0.139C0.23,-0.106 0.268,-0.09 0.314,-0.09Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,355.788,496.471)"><path d="M0.208,-0.458L0.208,-0.153C0.208,-0.132 0.213,-0.117 0.223,-0.109C0.232,-0.099 0.249,-0.095 0.272,-0.095L0.342,-0.095L0.342,-0L0.252,-0C0.201,-0 0.161,-0.012 0.134,-0.036C0.107,-0.06 0.093,-0.099 0.093,-0.153L0.093,-0.458L0.028,-0.458L0.028,-0.551L0.093,-0.551L0.093,-0.688L0.208,-0.688L0.208,-0.551L0.342,-0.551L0.342,-0.458L0.208,-0.458Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,380.288,496.471)"><path d="M0.037,-0.278C0.037,-0.333 0.049,-0.382 0.072,-0.425C0.094,-0.468 0.126,-0.501 0.166,-0.525C0.205,-0.548 0.249,-0.56 0.297,-0.56C0.34,-0.56 0.378,-0.552 0.411,-0.535C0.443,-0.518 0.469,-0.496 0.488,-0.471L0.488,-0.551L0.603,-0.551L0.603,-0L0.488,-0L0.488,-0.082C0.469,-0.056 0.442,-0.034 0.409,-0.017C0.376,0 0.338,0.009 0.295,0.009C0.248,0.009 0.204,-0.003 0.165,-0.028C0.126,-0.052 0.094,-0.086 0.072,-0.13C0.049,-0.173 0.037,-0.223 0.037,-0.278ZM0.488,-0.276C0.488,-0.314 0.48,-0.347 0.465,-0.375C0.449,-0.403 0.428,-0.424 0.403,-0.439C0.378,-0.454 0.35,-0.461 0.321,-0.461C0.292,-0.461 0.264,-0.454 0.239,-0.44C0.214,-0.425 0.193,-0.404 0.178,-0.377C0.162,-0.349 0.154,-0.316 0.154,-0.276C0.154,-0.24 0.162,-0.207 0.178,-0.178C0.193,-0.149 0.214,-0.128 0.24,-0.113C0.265,-0.097 0.292,-0.09 0.321,-0.09C0.35,-0.09 0.378,-0.097 0.403,-0.112C0.428,-0.127 0.449,-0.148 0.465,-0.177C0.48,-0.205 0.488,-0.238 0.488,-0.276Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,423.913,496.471)"><path d="M0.353,-0.56C0.396,-0.56 0.435,-0.551 0.47,-0.533C0.504,-0.515 0.531,-0.488 0.55,-0.453C0.569,-0.418 0.579,-0.375 0.579,-0.325L0.579,-0L0.466,-0L0.466,-0.308C0.466,-0.357 0.454,-0.395 0.429,-0.422C0.404,-0.448 0.371,-0.461 0.328,-0.461C0.285,-0.461 0.252,-0.448 0.227,-0.422C0.202,-0.395 0.189,-0.357 0.189,-0.308L0.189,-0L0.075,-0L0.075,-0.551L0.189,-0.551L0.189,-0.488C0.208,-0.511 0.232,-0.528 0.261,-0.541C0.29,-0.554 0.32,-0.56 0.353,-0.56Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,465.725,496.471)"><path d="M0.133,-0.624C0.112,-0.624 0.095,-0.631 0.081,-0.645C0.067,-0.659 0.06,-0.676 0.06,-0.697C0.06,-0.718 0.067,-0.735 0.081,-0.749C0.095,-0.763 0.112,-0.77 0.133,-0.77C0.153,-0.77 0.17,-0.763 0.184,-0.749C0.198,-0.735 0.205,-0.718 0.205,-0.697C0.205,-0.676 0.198,-0.659 0.184,-0.645C0.17,-0.631 0.153,-0.624 0.133,-0.624ZM0.189,-0.551L0.189,-0L0.075,-0L0.075,-0.551L0.189,-0.551Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,483.475,496.471)"><path d="M0.58,-0.289C0.58,-0.268 0.579,-0.25 0.576,-0.233L0.155,-0.233C0.158,-0.189 0.175,-0.154 0.204,-0.127C0.233,-0.1 0.269,-0.087 0.312,-0.087C0.373,-0.087 0.417,-0.113 0.442,-0.164L0.565,-0.164C0.548,-0.113 0.518,-0.072 0.475,-0.04C0.431,-0.007 0.377,0.009 0.312,0.009C0.259,0.009 0.212,-0.003 0.171,-0.027C0.129,-0.05 0.096,-0.084 0.073,-0.127C0.049,-0.169 0.037,-0.219 0.037,-0.276C0.037,-0.333 0.049,-0.383 0.072,-0.426C0.094,-0.468 0.127,-0.502 0.169,-0.525C0.21,-0.548 0.258,-0.56 0.312,-0.56C0.364,-0.56 0.41,-0.549 0.451,-0.526C0.492,-0.503 0.523,-0.471 0.546,-0.431C0.569,-0.389 0.58,-0.342 0.58,-0.289ZM0.461,-0.325C0.46,-0.367 0.445,-0.401 0.416,-0.426C0.387,-0.451 0.35,-0.464 0.307,-0.464C0.268,-0.464 0.234,-0.452 0.206,-0.427C0.178,-0.401 0.161,-0.368 0.156,-0.325L0.461,-0.325Z"/></g>
            <g transform="matrix(62.5,0,0,62.5,523.288,496.471)"><path d="M0.293,-0.275L0.547,-0L0.393,-0L0.189,-0.237L0.189,-0L0.075,-0L0.075,-0.74L0.189,-0.74L0.189,-0.31L0.389,-0.551L0.547,-0.551L0.293,-0.275Z"/></g>
          </g>
        </g>
      </g>
    </svg>
  `;

  const fullFlowIconSvg = `
    <svg viewBox="-418 -12 626 210" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <g fill="#808080">
        <path d="m -396.18563,-9.1876336 c -8.72771,0 -15.79309,7.0664818 -15.79309,15.7934515 V 175.01892 c 0,8.72807 7.06538,15.79345 15.79309,15.79345 h 199.99999 c 8.72769,0 15.79308,-7.06538 15.79308,-15.79345 V 6.6058179 c 0,-8.728065 -7.06539,-15.7934515 -15.79308,-15.7934515 z m 5.25901,21.0520896 h 189.48269 V 169.7599 h -26.31 v -10.51583 h -47.38071 V 169.7599 H -390.92771 V 11.864456 Z m 94.74098,42.102373 c -8.72879,0 -15.79308,7.065376 -15.79308,15.794175 0,8.728055 7.06429,15.793441 15.79308,15.793441 8.72879,0 15.79308,-7.065386 15.79308,-15.793441 0,-8.728799 -7.06429,-15.794175 -15.79308,-15.794175 z m -42.10345,18.432427 c -6.53548,0 -11.8543,5.300593 -11.8543,11.836058 0,6.534742 5.31882,11.834972 11.8543,11.834972 6.53583,0 11.83605,-5.30023 11.83605,-11.834972 0,-6.535465 -5.30022,-11.836058 -11.83605,-11.836058 z m 84.20691,0 c -6.53583,0 -11.83606,5.300593 -11.83606,11.836058 0,6.534742 5.30023,11.834972 11.83606,11.834972 6.53547,0 11.8543,-5.30023 11.8543,-11.834972 0,-6.535465 -5.31883,-11.836058 -11.83605,-11.836058 z m -42.10346,23.67103 c -11.37653,0 -23.28225,3.871317 -30.38009,9.706554 -3.70537,-1.1561 -7.76123,-1.80892 -11.72336,-1.80892 -12.67525,0 -26.32825,6.70615 -26.32825,15.03961 v 8.65038 h 136.86341 v -8.65038 c 0,-8.33419 -13.65301,-15.03961 -26.32825,-15.03961 -3.96213,0 -8.01872,0.65282 -11.72337,1.80892 -7.09784,-5.835237 -19.00356,-9.706554 -30.38009,-9.706554 z" />
        <path d="m -98.01682,33.784068 v 29.99972 h -55.00026 v 54.056642 h 55.00026 v 30.00024 l 81.853397,-57.028562 z" style="fill:none;stroke:#808080;stroke-width:15;stroke-linecap:round;stroke-linejoin:round" />
        <path d="m 29.866292,190.78764 c -5.55398,-0.38373 -10.68156,-2.96148 -13.94998,-7.01297 -2.30301,-2.85477 -3.67795,-6.0365 -4.25614,-9.84899 -0.16306,-1.07521 -0.16991,-4.42574 -0.16991,-83.109328 0,-78.4593 0.008,-82.0353604 0.16859,-83.0671294 0.58643,-3.750445 2.01428,-7.09377525 4.16422,-9.7505513 0.77148,-0.953358 2.43134,-2.548732 3.40199,-3.269835 2.75073,-2.043517 6.01489,-3.3084485 9.75056,-3.7785498 1.46203,-0.1839854 163.547158,-0.1839854 165.009198,0 3.73566,0.4701013 6.99983,1.7350328 9.75054,3.7785498 0.97066,0.721103 2.63051,2.316477 3.402,3.269835 2.14993,2.65677605 3.57779,6.0001063 4.16423,9.7505513 0.16132,1.031769 0.16858,4.6078294 0.16858,83.0671294 0,78.683588 -0.007,82.034118 -0.16991,83.109328 -0.8827,5.82045 -3.8162,10.55889 -8.42409,13.60735 -2.36498,1.5646 -5.07616,2.59094 -8.18948,3.1002 -0.98532,0.16117 -4.57345,0.16888 -82.69082,0.17764 -44.913448,0.006 -81.871758,-0.006 -82.129578,-0.0232 z m 82.645218,-27.34779 c 3.8565,-0.33179 6.59711,-0.70547 9.73479,-1.32732 10.70024,-2.12063 19.37853,-6.24493 26.01555,-12.3637 2.52299,-2.32598 4.76493,-5.03134 6.63749,-8.00945 0.91933,-1.4621 2.41453,-4.43013 3.05498,-6.06428 2.38536,-6.08631 3.25194,-12.63027 2.60065,-19.63859 -0.48759,-5.24675 -1.95841,-10.1202 -4.33595,-14.36684 -3.49838,-6.248616 -9.06233,-11.537638 -17.08101,-16.236998 -2.0318,-1.19073 -7.22467,-3.76993 -9.70366,-4.819616 -1.91318,-0.8101 -2.93144,-1.21066 -8.6255,-3.393116 -7.91899,-3.035233 -13.70517,-5.778802 -17.38048,-8.241117 -5.016658,-3.360948 -7.574538,-6.88111 -8.350818,-11.49245 -0.58001,-3.445405 -0.169,-6.534123 1.26009,-9.469274 0.84155,-1.728455 1.79051,-3.012521 3.27555,-4.432215 5.311098,-5.077444 13.958438,-7.075283 25.836538,-5.969156 7.58091,0.705966 15.00443,2.686984 21.52345,5.743678 0.87297,0.40933 1.59386,0.738776 1.60194,0.73211 0.0723,-0.05957 6.30894,-20.937538 6.27831,-21.017355 -0.0518,-0.135163 -2.39265,-1.211358 -4.29139,-1.973002 -6.10866,-2.450377 -13.66334,-4.167039 -21.40897,-4.864822 -5.72919,-0.516111 -11.81612,-0.548711 -16.87594,-0.09036 -12.836828,1.162845 -23.688948,5.360558 -31.694978,12.259927 -1.30696,1.126303 -3.6083,3.479356 -4.64658,4.750987 -4.99863,6.122069 -7.75992,13.135871 -8.34188,21.188685 -0.13545,1.874259 -0.0622,5.331922 0.15084,7.12539 1.18349,9.960714 6.27281,18.221786 15.46848,25.108786 5.96323,4.46608 13.42663,8.249162 23.234548,11.777202 3.46589,1.24672 4.56372,1.659906 6.49623,2.444916 12.2836,4.98978 18.20513,10.0372 19.96276,17.01599 0.47584,1.88937 0.66116,5.03785 0.41405,7.0341 -1.08352,8.75252 -7.82627,14.70355 -18.74647,16.54531 -2.20705,0.37223 -3.91759,0.51996 -6.7035,0.57892 -9.407098,0.19912 -19.828358,-1.76056 -29.017238,-5.45658 -2.06241,-0.82956 -3.32359,-1.40968 -5.6159,-2.58322 -1.10348,-0.56492 -2.01402,-1.01586 -2.02342,-1.00209 -0.01,0.0137 -1.39889,4.86829 -3.08776,10.78781 -2.46115,8.62644 -3.0483,10.78971 -2.95805,10.89845 0.20708,0.24952 4.33597,2.24721 6.04408,2.92433 7.89449,3.12947 17.95851,5.30207 27.47028,5.93022 0.82505,0.0545 1.711038,0.11418 1.968858,0.13264 0.25783,0.0185 2.64156,0.0218 5.29717,0.008 3.4262,-0.0185 5.33209,-0.0694 6.56286,-0.17535 z" />
      </g>
    </svg>
  `;

  const infoIconSvg = `
    <svg viewBox="0 0 24 24" width="16" height="16">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
    </svg>
  `;

  const copyIconSvg = `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
    </svg>
  `;

  const checkIconSvg = `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  `;

  const refreshIconSvg = `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="23 4 23 10 17 10"></polyline>
      <polyline points="1 20 1 14 7 14"></polyline>
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
    </svg>
  `;

  // HULPFUNCTIE VOOR INLEVERDATUMS MET GEKLEURDE BOLLETJES EN HOLLE CIRKEL
  function formatDueDateInfo(timestamp) {
    const redDot = '<span style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:#e53935; margin-right:6px; vertical-align:1px;"></span>';
    const greenDot = '<span style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:#388e3c; margin-right:6px; vertical-align:1px;"></span>';
    const hollowCircle = '<span style="display:inline-block; width:7px; height:7px; border-radius:50%; border:1.5px solid #333333; background-color:transparent; margin-right:6px; vertical-align:1px; box-sizing:border-box;"></span>';

    if (!timestamp) {
      return {
        displayText: 'Zonder inleverdatum',
        htmlText: `${hollowCircle}Zonder inleverdatum`,
        copyValue: 'Zonder inleverdatum'
      };
    }

    const dateObj = new Date(timestamp);
    if (isNaN(dateObj.getTime())) {
      return {
        displayText: 'Zonder inleverdatum',
        htmlText: `${hollowCircle}Zonder inleverdatum`,
        copyValue: 'Zonder inleverdatum'
      };
    }

    const year = dateObj.getFullYear();
    const month = dateObj.getMonth();
    const day = dateObj.getDate();

    const monthsShort = ['jan', 'feb', 'mrt', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
    const displayDateStr = `${day} ${monthsShort[month]} ${year}`;

    const monthPadded = String(month + 1).padStart(2, '0');
    const dayPadded = String(day).padStart(2, '0');
    const isoDateStr = `${year}-${monthPadded}-${dayPadded}`;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const targetMidnight = new Date(year, month, day);

    let displayText = '';
    let dotHtml = '';

    if (targetMidnight.getTime() === today.getTime()) {
      displayText = 'Moet vandaag worden ingeleverd';
      dotHtml = redDot;
    } else if (targetMidnight.getTime() > today.getTime()) {
      displayText = `Moet worden ingeleverd op ${displayDateStr}`;
      dotHtml = redDot;
    } else {
      displayText = `Moest worden ingeleverd op ${displayDateStr}`;
      dotHtml = greenDot;
    }

    return {
      displayText: displayText,
      htmlText: `${dotHtml}${displayText}`,
      copyValue: isoDateStr
    };
  }

  const popup = document.createElement('div');
  popup.id = 'ba-skore-popup';
  popup.innerHTML = `
    <div class="ba-popup-header" id="ba-skore-popup-header">
      <div class="ba-popup-logo">${logoSvg}</div>
      <div class="ba-popup-controls">
        <button class="ba-popup-btn" id="ba-min-btn" title="Inklappen">&minus;</button>
        <button class="ba-popup-btn" id="ba-close-btn" title="Sluiten">&times;</button>
      </div>
    </div>
    <div class="ba-popup-content" id="ba-popup-content"></div>
  `;

  document.body.appendChild(popup);

  const contentContainer = popup.querySelector('#ba-popup-content');

  // HOME SCHERM
  function renderHomeView() {
    contentContainer.className = 'ba-popup-content ba-home-view';
    contentContainer.innerHTML = `
      <div class="ba-popup-sms-icon">${fullFlowIconSvg}</div>
      <p class="ba-popup-intro">Deze Chrome extensie helpt je om cijfers over te dragen van Classroom naar Skore.</p>
      <button class="ba-btn-start" id="ba-start-btn">START</button>
      <p class="ba-popup-info-link">
        <a href="https://babocomm.github.io/classroom_to_skore/" target="_blank" rel="noopener noreferrer">
          ${infoIconSvg}
          <span>Wat is dit?</span>
        </a>
      </p>
      <div style="margin-top: 18px; text-align: center; border-top: 1px dashed #ddd; padding-top: 14px;">
        <a href="https://babocomm.github.io/classroom_to_skore/index.html#uitschakelen" target="_blank" rel="noopener noreferrer" style="display: inline-block; text-decoration: none; background: transparent; border: 1px solid #bbb; color: #666; font-size: 11px; padding: 5px 10px; border-radius: 4px; cursor: pointer; transition: all 0.2s ease;">
          Deze extensie uitschakelen in Chrome
        </a>
      </div>
    `;
    contentContainer.scrollTop = 0;
  }

  // LAADSCHERM
  function renderLoadingView() {
    contentContainer.className = 'ba-popup-content';
    contentContainer.innerHTML = `
      <div class="ba-loading-box">
        <div class="ba-spinner"></div>
        <p style="font-weight: 500; margin: 0;">Gegevens ophalen uit Google Classroom...</p>
        <p style="font-size: 12px; color: #777; margin: 0;">Eventueel verschijnt er een pop-up om in te loggen.</p>
      </div>
    `;
    contentContainer.scrollTop = 0;
  }

  // FOUTSCHERM
  function renderErrorView(message) {
    contentContainer.className = 'ba-popup-content';
    contentContainer.innerHTML = `
      <button class="ba-btn-back" id="ba-back-to-home">&larr; Terug</button>
      <div class="ba-section-title"><span>Fout bij ophalen</span></div>
      <div class="ba-error-box">
        <strong>Er is iets misgegaan:</strong><br />${message}
      </div>
      <button class="ba-btn-start" id="ba-start-btn" style="margin-top: 16px;">Opnieuw proberen</button>
    `;
    contentContainer.scrollTop = 0;
  }

  // FILTER & SORTEER LOGICA (FILTERT OP KLAS & SORTEERT OP DATUM)
  function getFilteredAndSortedAssignments() {
    let list = [...classroomAssignments];

    // 1. Filteren op klas indien niet 'ALL'
    if (selectedCourseFilter !== 'ALL') {
      list = list.filter(item => item.course === selectedCourseFilter);
    }

    // 2. Sorteren op datum
    list.sort((a, b) => {
      if (a.dueDateTimestamp && b.dueDateTimestamp) {
        return sortState.dir === 'desc'
          ? b.dueDateTimestamp - a.dueDateTimestamp
          : a.dueDateTimestamp - b.dueDateTimestamp;
      }
      if (a.dueDateTimestamp && !b.dueDateTimestamp) return -1;
      if (!a.dueDateTimestamp && b.dueDateTimestamp) return 1;

      return b.creationTimestamp - a.creationTimestamp;
    });

    return list;
  }

  // VIEW 2: OPDRACHTEN OVERZICHT (MET KLASSEN DROPDOWN FILTER)
  function renderOverviewView(restoreScroll = false) {
    contentContainer.className = 'ba-popup-content';

    const displayAssignments = getFilteredAndSortedAssignments();

    // Unieke klasnamen ophalen en alfabetisch sorteren voor de dropdown
    const uniqueCourses = [...new Set(classroomAssignments.map(a => a.course))].sort();

    const dateSortIcon = sortState.dir === 'desc' ? ' &#8595;' : ' &#8593;';

    let html = `
      <button class="ba-btn-back" id="ba-back-to-home">&larr; Terug</button>
      <div class="ba-section-title">
        <span style="display: inline-flex; align-items: center; gap: 6px;">
          <span>Opdrachten in dit schooljaar</span>
          <button class="ba-btn-refresh" id="ba-refresh-btn" title="Opdrachten herladen">
            ${refreshIconSvg}
          </button>
        </span>
        <span style="font-size: 12px; color: #666; font-weight: 400;">${displayAssignments.length} opdrachten</span>
      </div>

      <div class="ba-sort-bar">
        <button class="ba-btn-sort active" id="ba-sort-date">
          <span>Sorteer op datum</span>${dateSortIcon}
        </button>

        <!-- DROPDOWN VOOR KLASSECTIE -->
        <select class="ba-btn-sort ba-select-course" id="ba-filter-course">
          <option value="ALL" ${selectedCourseFilter === 'ALL' ? 'selected' : ''}>Alle klassen</option>
          ${uniqueCourses.map(courseName => `
            <option value="${courseName}" ${selectedCourseFilter === courseName ? 'selected' : ''}>
              ${courseName}
            </option>
          `).join('')}
        </select>
      </div>
    `;

    if (displayAssignments.length === 0) {
      html += `<p style="font-size: 13px; color: #666;">Geen opdrachten gevonden voor deze selectie.</p>`;
    }

    displayAssignments.forEach(item => {
      const dateInfo = formatDueDateInfo(item.dueDateTimestamp);

      html += `
        <div class="ba-assignment-card" data-id="${item.id}">
          <div class="ba-card-course">${item.course}</div>
          <div class="ba-card-title">${item.title}</div>
          <div class="ba-card-date-line">${dateInfo.htmlText}</div>
          <div class="ba-card-stats">
            <span class="ba-stat-pill submitted">Ingeleverd: ${item.ingeleverd}</span>
            <span class="ba-stat-pill">Toegewezen: ${item.toegewezen}</span>
            <span class="ba-stat-pill">Beoordeeld: ${item.beoordeeld}</span>
          </div>
        </div>
      `;
    });

    contentContainer.innerHTML = html;

    if (restoreScroll) {
      contentContainer.scrollTop = overviewScrollTop;
    } else {
      contentContainer.scrollTop = 0;
      overviewScrollTop = 0;
    }
  }

  // VIEW 3: DETAIL SCHERM
  function renderDetailView(assignment) {
    currentSelectedAssignment = assignment;
    contentContainer.className = 'ba-popup-content';

    const dateInfo = formatDueDateInfo(assignment.dueDateTimestamp);

    let html = `
      <button class="ba-btn-back" id="ba-back-to-overview">&larr; Terug</button>
      <div class="ba-detail-header">
        <div class="ba-detail-course">${assignment.course}</div>
        <div class="ba-detail-title">
          <span>${assignment.title}</span>
          <button class="ba-btn-copy" title="Kopieer titel naar klembord" data-copy="${assignment.title}">
            ${copyIconSvg}
          </button>
        </div>
        <div class="ba-detail-date-container">
          <span>${dateInfo.htmlText}</span>
          <button class="ba-btn-copy" title="Kopieer datum naar klembord" data-copy="${dateInfo.copyValue}">
            ${copyIconSvg}
          </button>
        </div>
      </div>
      <div class="ba-section-title">
        <span>Studenten (${assignment.students.length})</span>
      </div>
      <div class="ba-student-list">
    `;

    assignment.students.forEach(student => {
      const isGradeSet = student.grade !== 'Nog geen punt';
      let gradeClass = '';

      if (!isGradeSet) {
        gradeClass = 'empty';
      } else if (student.isDraft) {
        gradeClass = 'draft';
      }

      html += `
        <div class="ba-student-row">
          <span class="ba-student-name">${student.name}</span>
          <span class="ba-student-grade ${gradeClass}">${student.grade}</span>
        </div>
      `;
    });

    html += `
      </div>
      <hr class="ba-divider" />
      <button class="ba-btn-recalculate" id="ba-btn-open-recalculate">
        <span>&#8635;</span> Herrekenen naar nieuw maximum
      </button>
    `;

    contentContainer.innerHTML = html;
    contentContainer.scrollTop = 0;
  }

  // VIEW 4: HERREKENEN SCHERM
  function renderRecalculateView(assignment) {
    contentContainer.className = 'ba-popup-content';
    const dateInfo = formatDueDateInfo(assignment.dueDateTimestamp);

    contentContainer.innerHTML = `
      <button class="ba-btn-back" id="ba-back-to-detail">&larr; Terug</button>
      <div class="ba-detail-header">
        <div class="ba-detail-course">${assignment.course}</div>
        <div class="ba-detail-title">
          <span>${assignment.title}</span>
          <button class="ba-btn-copy" title="Kopieer titel naar klembord" data-copy="${assignment.title}">
            ${copyIconSvg}
          </button>
        </div>
        <div class="ba-detail-date-container">
          <span>${dateInfo.htmlText}</span>
          <button class="ba-btn-copy" title="Kopieer datum naar klembord" data-copy="${dateInfo.copyValue}">
            ${copyIconSvg}
          </button>
        </div>
      </div>
      <div class="ba-section-title">
        <span>Herrekenen naar nieuw maximum</span>
      </div>
      <div class="ba-recalc-box">
        <div class="ba-input-group">
          <label class="ba-input-label" for="ba-new-max">Nieuw maximum (bijv. 10 of 20):</label>
          <input type="number" id="ba-new-max" class="ba-input-number" placeholder="Vul maximum in..." min="1" step="0.5" />
        </div>
        <button class="ba-btn-start" id="ba-btn-apply-recalculate" style="margin-bottom: 0;">Herrekenen</button>
      </div>
    `;
    contentContainer.scrollTop = 0;
  }

  // WISKUNDIGE AFRONDING OP 0,5
  function recalculateGrade(gradeStr, newMax) {
    if (!gradeStr || gradeStr === 'Nog geen punt') return gradeStr;

    let score = null;
    let oldMax = null;

    if (gradeStr.includes('/')) {
      const parts = gradeStr.split('/');
      score = parseFloat(parts[0]);
      oldMax = parseFloat(parts[1]);
    } else if (gradeStr.includes('%')) {
      score = parseFloat(gradeStr.replace('%', ''));
      oldMax = 100;
    }

    if (score === null || oldMax === null || isNaN(score) || isNaN(oldMax) || oldMax === 0) {
      return gradeStr;
    }

    const rawNewScore = (score / oldMax) * newMax;
    const roundedScore = Math.round(rawNewScore * 2) / 2;

    return `${roundedScore}/${newMax}`;
  }

  // CLASSROOM DATA OPHALEN
  function loadClassroomData() {
    renderLoadingView();
    chrome.runtime.sendMessage({ action: 'FETCH_CLASSROOM_DATA' }, (response) => {
      if (chrome.runtime.lastError) {
        renderErrorView(chrome.runtime.lastError.message);
        return;
      }
      if (response && response.success) {
        classroomAssignments = response.data;
        renderOverviewView();
      } else {
        renderErrorView(response ? response.error : 'Onbekende fout bij ophalen van gegevens.');
      }
    });
  }

  // DROPDOWN CHANGE EVENT LISTENER (VOOR KLAS-SELECTIE)
  contentContainer.addEventListener('change', (e) => {
    if (e.target.id === 'ba-filter-course') {
      selectedCourseFilter = e.target.value;
      renderOverviewView();
    }
  });

  // CENTRALE EVENT DELEGATION
  contentContainer.addEventListener('click', (e) => {
    // KOPIEERKNOPPEN
    const copyBtn = e.target.closest('.ba-btn-copy');
    if (copyBtn) {
      const textToCopy = copyBtn.getAttribute('data-copy');
      if (textToCopy) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          copyBtn.classList.add('copied');
          copyBtn.innerHTML = checkIconSvg;
          setTimeout(() => {
            copyBtn.classList.remove('copied');
            copyBtn.innerHTML = copyIconSvg;
          }, 1500);
        });
      }
      return;
    }

    // SORTEER OP DATUM (WISSELEN OMSCHAKELING ASC / DESC)
    const sortDateBtn = e.target.closest('#ba-sort-date');
    if (sortDateBtn) {
      sortState.dir = sortState.dir === 'desc' ? 'asc' : 'desc';
      renderOverviewView();
      return;
    }

    // START KNOP
    const startBtn = e.target.closest('#ba-start-btn');
    if (startBtn) {
      popup.classList.add('ba-expanded');
      loadClassroomData();
      return;
    }

    // HERLAAD KNOP
    const refreshBtn = e.target.closest('#ba-refresh-btn');
    if (refreshBtn) {
      loadClassroomData();
      return;
    }

    // TERUG NAAR HOME
    const backToHome = e.target.closest('#ba-back-to-home');
    if (backToHome) {
      popup.classList.remove('ba-expanded');
      renderHomeView();
      return;
    }

    // TERUG NAAR OVERZICHT
    const backToOverview = e.target.closest('#ba-back-to-overview');
    if (backToOverview) {
      renderOverviewView(true);
      return;
    }

    // OPDRACHT KAART GEKLIKT
    const card = e.target.closest('.ba-assignment-card');
    if (card) {
      overviewScrollTop = contentContainer.scrollTop;
      const id = card.getAttribute('data-id');
      const selectedItem = classroomAssignments.find(a => a.id === id);
      if (selectedItem) {
        renderDetailView(selectedItem);
      }
      return;
    }

    // HERREKEN-SCHERM OPENEN
    const openRecalcBtn = e.target.closest('#ba-btn-open-recalculate');
    if (openRecalcBtn && currentSelectedAssignment) {
      renderRecalculateView(currentSelectedAssignment);
      return;
    }

    // TERUG VAN HERREKENEN
    const backToDetail = e.target.closest('#ba-back-to-detail');
    if (backToDetail && currentSelectedAssignment) {
      renderDetailView(currentSelectedAssignment);
      return;
    }

    // HERREKENING TOEPASSEN
    const applyRecalcBtn = e.target.closest('#ba-btn-apply-recalculate');
    if (applyRecalcBtn && currentSelectedAssignment) {
      const inputEl = popup.querySelector('#ba-new-max');
      const newMaxVal = parseFloat(inputEl ? inputEl.value : '');

      if (!isNaN(newMaxVal) && newMaxVal > 0) {
        currentSelectedAssignment.students.forEach(student => {
          student.grade = recalculateGrade(student.grade, newMaxVal);
        });
        renderDetailView(currentSelectedAssignment);
      } else {
        if (inputEl) inputEl.style.borderColor = '#c50650';
      }
      return;
    }
  });

  renderHomeView();

  // BEDIENING BEDINKNOPPEN EN INKLAPPEN
  const minBtn = popup.querySelector('#ba-min-btn');
  const header = popup.querySelector('#ba-skore-popup-header');
  const closeBtn = popup.querySelector('#ba-close-btn');

  let isMinimized = false;
  let isDragging = false;
  let offsetX = 0;
  let offsetY = 0;

  function toggleMinimize(e) {
    if (e) e.stopPropagation();
    isMinimized = !isMinimized;

    if (isMinimized) {
      popup.classList.add('ba-minimized');
      minBtn.innerHTML = '&#43;';
      minBtn.title = 'Uitklappen';
    } else {
      popup.classList.remove('ba-minimized');
      minBtn.innerHTML = '&minus;';
      minBtn.title = 'Inklappen';
    }
  }

  if (minBtn) minBtn.addEventListener('click', toggleMinimize);

  if (closeBtn) {
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      popup.remove();
    });
  }

  // RESPONSIVITEIT & SOEPEL VERSLEPEN VIA POINTER EVENTS
  if (header) {
    header.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.ba-popup-btn')) return;

      isDragging = true;
      popup.classList.add('ba-dragging');

      const rect = popup.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;

      header.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    header.addEventListener('pointermove', (e) => {
      if (!isDragging) return;

      let newX = e.clientX - offsetX;
      let newY = e.clientY - offsetY;

      const maxX = window.innerWidth - popup.offsetWidth;
      const maxY = window.innerHeight - popup.offsetHeight;

      newX = Math.max(10, Math.min(newX, maxX - 10));
      newY = Math.max(10, Math.min(newY, maxY - 10));

      popup.style.left = `${newX}px`;
      popup.style.top = `${newY}px`;
      popup.style.right = 'auto';
      popup.style.bottom = 'auto';
    });

    const stopDragging = (e) => {
      if (isDragging) {
        isDragging = false;
        popup.classList.remove('ba-dragging');
        try {
          header.releasePointerCapture(e.pointerId);
        } catch (err) {}
      }
    };

    header.addEventListener('pointerup', stopDragging);
    header.addEventListener('pointercancel', stopDragging);
  }
})();
